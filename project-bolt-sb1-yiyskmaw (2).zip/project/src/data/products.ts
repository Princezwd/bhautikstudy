export type Category = 'notes' | 'assignments' | 'tests';

export interface Product {
  id: string;
  title: string;
  description: string;
  category: Category;
  credits: number;
  rating: number;
  class?: string;
  tags: string[];
  features: string[];
}

export const products: Product[] = [
  {
    id: '1',
    title: 'Class 11 Physics Complete Notes',
    description: 'Comprehensive notes covering the entire CBSE Class 11 Physics syllabus. Includes detailed explanations, diagrams, and example problems.',
    category: 'notes',
    credits: 150,
    rating: 4.8,
    class: '11',
    tags: ['class11', 'notes', 'cbse'],
    features: [
      'Covers all chapters in NCERT Class 11 Physics',
      'Includes 200+ diagrams and illustrations',
      'Contains solved examples for every concept',
      'Chapter summaries and important formulas',
      'Digital PDF format for easy access'
    ]
  },
  {
    id: '2',
    title: 'JEE Advanced Physics Problem Set',
    description: 'A collection of challenging problems designed to prepare students for JEE Advanced Physics. Includes step-by-step solutions.',
    category: 'assignments',
    credits: 200,
    rating: 4.9,
    tags: ['jee', 'advanced', 'problems'],
    features: [
      '500+ JEE Advanced level problems',
      'Categorized by topic and difficulty level',
      'Detailed step-by-step solutions',
      'Tips and tricks for solving complex problems',
      'Regular updates with new problems'
    ]
  },
  {
    id: '3',
    title: 'NEET Physics Mock Test Series',
    description: 'A series of 10 mock tests designed to simulate the NEET exam environment. Covers all topics in the NEET Physics syllabus.',
    category: 'tests',
    credits: 250,
    rating: 4.7,
    tags: ['neet', 'mock tests', 'exam prep'],
    features: [
      '10 full-length NEET pattern mock tests',
      'Covers complete Physics syllabus',
      'Detailed solutions and explanations',
      'Performance analysis and weak area identification',
      'Timed test environment'
    ]
  },
  {
    id: '4',
    title: 'Mechanics & Thermodynamics Notes',
    description: 'In-depth notes on Mechanics and Thermodynamics for Class 11 and JEE preparation. Includes solved numerical problems.',
    category: 'notes',
    credits: 120,
    rating: 4.6,
    class: '11',
    tags: ['mechanics', 'thermodynamics', 'jee', 'class11'],
    features: [
      'Comprehensive coverage of Newton\'s Laws, Kinematics, and Thermodynamics',
      '150+ solved numerical problems',
      'Conceptual clarity with detailed explanations',
      'Exam-focused content',
      'Digital format with printable option'
    ]
  },
  {
    id: '5',
    title: 'Electricity & Magnetism Assignment',
    description: 'A comprehensive assignment set covering all concepts in Electricity and Magnetism for Class 12 students.',
    category: 'assignments',
    credits: 100,
    rating: 4.5,
    class: '12',
    tags: ['electricity', 'magnetism', 'class12'],
    features: [
      '200+ problems of varying difficulty',
      'Covers Coulomb\'s Law, Electric Fields, Magnetic Fields, and Electromagnetic Induction',
      'Detailed solutions included',
      'Concept-reinforcing questions',
      'Suitable for board exam preparation'
    ]
  },
  {
    id: '6',
    title: 'Modern Physics Notes for NEET',
    description: 'Specialized notes on Modern Physics topics tailored for NEET aspirants. Includes quantum mechanics, nuclear physics, and more.',
    category: 'notes',
    credits: 180,
    rating: 4.8,
    tags: ['modern physics', 'neet', 'quantum'],
    features: [
      'NEET-focused content on Modern Physics',
      'Simplified explanations of complex topics',
      'Important formulas and derivations',
      'Previous year NEET questions with solutions',
      'Regular updates with latest exam pattern'
    ]
  },
  {
    id: '7',
    title: 'Class 12 Physics Full Test Series',
    description: 'A comprehensive test series for Class 12 Physics, designed to prepare students for board examinations.',
    category: 'tests',
    credits: 200,
    rating: 4.7,
    class: '12',
    tags: ['class12', 'boards', 'test series'],
    features: [
      '15 chapter-wise tests',
      '5 full syllabus mock tests',
      'CBSE pattern questions',
      'Detailed solutions and explanations',
      'Performance tracking'
    ]
  },
  {
    id: '8',
    title: 'Wave Optics & Modern Physics Assignment',
    description: 'Challenging assignment problems on Wave Optics and Modern Physics for JEE and NEET preparation.',
    category: 'assignments',
    credits: 150,
    rating: 4.6,
    tags: ['wave optics', 'modern physics', 'jee', 'neet'],
    features: [
      '150+ problems on Wave Optics and Modern Physics',
      'Graded difficulty level from basic to advanced',
      'Includes numerical and conceptual problems',
      'Detailed step-by-step solutions',
      'Focus on frequently asked concepts in competitive exams'
    ]
  },
  {
    id: '9',
    title: 'Electrodynamics Advanced Notes',
    description: 'Advanced notes on Electrodynamics covering Maxwell\'s equations, electromagnetic waves, and applications.',
    category: 'notes',
    credits: 220,
    rating: 4.9,
    class: '12',
    tags: ['electrodynamics', 'advanced', 'jee', 'class12'],
    features: [
      'In-depth coverage of Electrodynamics',
      'Mathematical approach with detailed derivations',
      'Advanced concepts explained simply',
      'Practical applications and examples',
      'Suitable for advanced JEE preparation'
    ]
  },
  {
    id: '10',
    title: 'Physics Formula Handbook',
    description: 'A comprehensive collection of all important physics formulas for quick reference during exam preparation.',
    category: 'notes',
    credits: 80,
    rating: 4.5,
    tags: ['formulas', 'reference', 'jee', 'neet'],
    features: [
      '500+ formulas from all physics topics',
      'Organized by chapters and topics',
      'Important derivations included',
      'Quick reference format',
      'Digital and printable format'
    ]
  },
  {
    id: '11',
    title: 'JEE Main Physics Test Papers',
    description: 'A collection of 20 test papers modeled on the JEE Main examination pattern with detailed solutions.',
    category: 'tests',
    credits: 180,
    rating: 4.7,
    tags: ['jee', 'main', 'test papers'],
    features: [
      '20 JEE Main pattern test papers',
      'Updated according to latest exam pattern',
      'Includes MCQs and numerical value questions',
      'Detailed solutions with shortcuts',
      'Performance analysis tools'
    ]
  },
  {
    id: '12',
    title: 'Rotational Dynamics Problem Set',
    description: 'Specialized problem set focusing on Rotational Dynamics, one of the challenging topics in JEE Physics.',
    category: 'assignments',
    credits: 120,
    rating: 4.6,
    tags: ['rotational dynamics', 'mechanics', 'jee'],
    features: [
      '150+ problems on Rotational Dynamics',
      'Graded from basic to JEE Advanced level',
      'Detailed solutions with multiple approaches',
      'Tips and tricks for solving complex problems',
      'Concept reinforcement through varied problem types'
    ]
  }
];