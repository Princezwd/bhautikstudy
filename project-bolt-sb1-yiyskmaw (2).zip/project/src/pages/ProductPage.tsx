import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, CheckCircle, Star, Download, ShoppingCart, File, BookOpen, PenTool } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '../context/AuthContext';
import { products, Product } from '../data/products';

const ProductPage: React.FC = () => {
  const { productId } = useParams<{ productId: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [purchased, setPurchased] = useState(false);
  
  const { user, updateCredits } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    // Simulate API call to fetch product
    setIsLoading(true);
    
    setTimeout(() => {
      const foundProduct = products.find(p => p.id === productId);
      
      if (foundProduct) {
        setProduct(foundProduct);
      } else {
        setError('Product not found');
      }
      
      setIsLoading(false);
    }, 500);
  }, [productId]);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'notes':
        return <BookOpen size={18} />;
      case 'assignments':
        return <PenTool size={18} />;
      case 'tests':
        return <File size={18} />;
      default:
        return <File size={18} />;
    }
  };

  const handlePurchase = () => {
    if (!user) {
      navigate('/login');
      return;
    }
    
    if (!product) return;
    
    if (user.credits < product.credits) {
      setError('Insufficient credits. Please add more credits to your account.');
      return;
    }
    
    setIsPurchasing(true);
    
    // Simulate purchase process
    setTimeout(() => {
      const newCredits = user.credits - product.credits;
      updateCredits(newCredits);
      setPurchased(true);
      setIsPurchasing(false);
    }, 1500);
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8 flex items-center justify-center h-80">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[hsl(var(--primary-color))]"></div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white p-8 rounded-lg shadow-sm text-center">
          <h2 className="text-2xl font-bold mb-4">Error</h2>
          <p className="text-gray-600 mb-6">{error || 'Product not found'}</p>
          <Link to="/store" className="btn btn-primary">
            Back to Store
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <Link to="/store" className="inline-flex items-center text-gray-600 hover:text-gray-900">
          <ArrowLeft size={20} className="mr-2" /> Back to Store
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Product Image/Preview */}
        <motion.div 
          className="lg:col-span-2 bg-white rounded-lg shadow-sm overflow-hidden"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
        >
          <div className="h-64 bg-gradient-to-r from-blue-100 to-blue-50 flex items-center justify-center">
            <div className="text-6xl text-blue-700">
              {getCategoryIcon(product.category)}
            </div>
          </div>
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <span className={`badge ${
                product.category === 'notes' ? 'badge-primary' :
                product.category === 'assignments' ? 'badge-secondary' :
                'bg-green-100 text-green-700'
              }`}>
                {product.category}
              </span>
              <div className="flex items-center text-yellow-500">
                <Star size={16} fill="currentColor" />
                <span className="ml-1 text-gray-700">{product.rating}</span>
              </div>
            </div>
            <h1 className="text-2xl font-bold mb-2">{product.title}</h1>
            <p className="text-gray-700 mb-6">{product.description}</p>
            
            <div className="space-y-4">
              <h3 className="font-semibold text-lg">What's Included:</h3>
              <ul className="space-y-2">
                {product.features.map((feature, index) => (
                  <li key={index} className="flex items-start">
                    <CheckCircle size={20} className="text-green-500 mr-2 flex-shrink-0 mt-1" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </motion.div>

        {/* Purchase Details */}
        <motion.div 
          className="bg-white rounded-lg shadow-sm p-6 h-fit"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3 }}
        >
          <h2 className="text-xl font-bold mb-4">Purchase Details</h2>
          
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-gray-600">Price:</span>
              <span className="font-semibold text-lg">{product.credits} Credits</span>
            </div>
            
            <div className="flex justify-between items-center mb-4">
              <span className="text-gray-600">Your Credits:</span>
              <span className="font-semibold text-lg">{user ? user.credits : '—'}</span>
            </div>
            
            {user && user.credits < product.credits && (
              <div className="text-red-500 text-sm mb-4">
                You don't have enough credits to purchase this item.
              </div>
            )}
          </div>
          
          {error && (
            <div className="bg-red-50 text-red-600 p-3 rounded-md mb-4">
              {error}
            </div>
          )}
          
          {purchased ? (
            <div className="space-y-4">
              <div className="bg-green-50 text-green-600 p-4 rounded-md flex items-center">
                <CheckCircle size={20} className="mr-2" />
                <span>Successfully purchased!</span>
              </div>
              <button className="btn btn-primary w-full flex items-center justify-center">
                <Download size={18} className="mr-2" />
                Download Material
              </button>
            </div>
          ) : (
            <button
              onClick={handlePurchase}
              disabled={isPurchasing || !user || (user && user.credits < product.credits)}
              className={`btn w-full flex items-center justify-center ${
                !user || (user && user.credits < product.credits)
                  ? 'bg-gray-300 cursor-not-allowed'
                  : 'btn-primary'
              }`}
            >
              {isPurchasing ? (
                <span className="inline-flex items-center">
                  <span className="animate-spin h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full"></span>
                  Processing...
                </span>
              ) : (
                <>
                  <ShoppingCart size={18} className="mr-2" />
                  {user ? 'Purchase Now' : 'Login to Purchase'}
                </>
              )}
            </button>
          )}
          
          <div className="mt-6 space-y-4">
            <h3 className="font-semibold">Related Tags:</h3>
            <div className="flex flex-wrap gap-2">
              {product.tags.map(tag => (
                <Link 
                  key={tag} 
                  to={`/store?tag=${tag}`}
                  className="px-3 py-1 bg-gray-100 rounded-full text-sm hover:bg-gray-200"
                >
                  {tag}
                </Link>
              ))}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Related Products */}
      <div className="mt-12">
        <h2 className="text-2xl font-bold mb-6">Related Materials</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {products
            .filter(p => 
              p.id !== product.id && 
              (p.category === product.category || 
                p.tags.some(tag => product.tags.includes(tag)))
            )
            .slice(0, 3)
            .map(relatedProduct => (
              <motion.div
                key={relatedProduct.id}
                className="card overflow-hidden"
                whileHover={{ y: -5 }}
              >
                <div className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className={`badge ${
                      relatedProduct.category === 'notes' ? 'badge-primary' :
                      relatedProduct.category === 'assignments' ? 'badge-secondary' :
                      'bg-green-100 text-green-700'
                    }`}>
                      {relatedProduct.category}
                    </span>
                    <span className="font-semibold">{relatedProduct.credits} Credits</span>
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{relatedProduct.title}</h3>
                  <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                    {relatedProduct.description}
                  </p>
                  <Link 
                    to={`/store/${relatedProduct.id}`} 
                    className="btn btn-primary w-full"
                  >
                    View Details
                  </Link>
                </div>
              </motion.div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default ProductPage;