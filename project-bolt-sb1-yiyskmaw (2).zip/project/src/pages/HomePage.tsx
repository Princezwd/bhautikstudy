import React from 'react';
import { Link } from 'react-router-dom';
import { BookOpen, Trophy, Users, CreditCard, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';

const HomePage: React.FC = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-700 via-blue-600 to-blue-800 text-white py-16 md:py-24">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center">
            <motion.div 
              className="md:w-1/2 mb-8 md:mb-0"
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
                Master Physics with <span className="text-yellow-300">BHAUTIK STUDY</span>
              </h1>
              <p className="text-xl mb-8 opacity-90">
                Comprehensive resources for 11th, 12th, JEE and NEET students to excel in physics.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/register" className="btn bg-yellow-400 text-blue-900 hover:bg-yellow-300">
                  Get Started Free
                </Link>
                <Link to="/store" className="btn bg-white/20 backdrop-blur-sm hover:bg-white/30">
                  Explore Resources
                </Link>
              </div>
            </motion.div>
            <motion.div 
              className="md:w-1/2"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <img 
                src="https://images.pexels.com/photos/8197527/pexels-photo-8197527.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Student studying physics" 
                className="rounded-lg shadow-lg"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Choose BHAUTIK STUDY</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our platform is designed to help physics students achieve academic excellence through quality learning resources.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <motion.div 
              className="card p-6 text-center"
              whileHover={{ y: -5 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <div className="bg-blue-100 text-blue-700 h-14 w-14 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Quality Notes</h3>
              <p className="text-gray-600">
                Comprehensive and well-structured notes covering all important physics topics.
              </p>
            </motion.div>
            
            <motion.div 
              className="card p-6 text-center"
              whileHover={{ y: -5 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.2 }}
            >
              <div className="bg-green-100 text-green-700 h-14 w-14 rounded-full flex items-center justify-center mx-auto mb-4">
                <Trophy size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Exam Preparation</h3>
              <p className="text-gray-600">
                Specially designed materials for competitive exams like JEE and NEET.
              </p>
            </motion.div>
            
            <motion.div 
              className="card p-6 text-center"
              whileHover={{ y: -5 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.3 }}
            >
              <div className="bg-purple-100 text-purple-700 h-14 w-14 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Expert Faculty</h3>
              <p className="text-gray-600">
                Content created by experienced educators with proven track records.
              </p>
            </motion.div>
            
            <motion.div 
              className="card p-6 text-center"
              whileHover={{ y: -5 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.4 }}
            >
              <div className="bg-yellow-100 text-yellow-700 h-14 w-14 rounded-full flex items-center justify-center mx-auto mb-4">
                <CreditCard size={28} />
              </div>
              <h3 className="text-xl font-semibold mb-2">Credit System</h3>
              <p className="text-gray-600">
                Flexible credit system with 100 free credits for new registrations.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Explore Study Materials</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Browse through our extensive collection of study materials designed for different needs.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <motion.div 
              className="card overflow-hidden"
              whileHover={{ scale: 1.03 }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
            >
              <img 
                src="https://images.pexels.com/photos/5428833/pexels-photo-5428833.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Class 11 Physics" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">Class 11 Physics</h3>
                <p className="text-gray-600 mb-4">
                  Comprehensive notes and practice materials for CBSE Class 11 Physics syllabus.
                </p>
                <Link to="/store?class=11" className="inline-flex items-center text-blue-700 font-medium">
                  Explore Materials <ArrowRight size={16} className="ml-1" />
                </Link>
              </div>
            </motion.div>
            
            <motion.div 
              className="card overflow-hidden"
              whileHover={{ scale: 1.03 }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <img 
                src="https://images.pexels.com/photos/5428004/pexels-photo-5428004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Class 12 Physics" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">Class 12 Physics</h3>
                <p className="text-gray-600 mb-4">
                  Complete study material for CBSE Class 12 Physics to excel in board exams.
                </p>
                <Link to="/store?class=12" className="inline-flex items-center text-blue-700 font-medium">
                  Explore Materials <ArrowRight size={16} className="ml-1" />
                </Link>
              </div>
            </motion.div>
            
            <motion.div 
              className="card overflow-hidden"
              whileHover={{ scale: 1.03 }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.2 }}
            >
              <img 
                src="https://images.pexels.com/photos/6238050/pexels-photo-6238050.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="JEE Physics" 
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">JEE Physics</h3>
                <p className="text-gray-600 mb-4">
                  Specialized study materials, mock tests, and practice problems for JEE aspirants.
                </p>
                <Link to="/store?tag=jee" className="inline-flex items-center text-blue-700 font-medium">
                  Explore Materials <ArrowRight size={16} className="ml-1" />
                </Link>
              </div>
            </motion.div>
            
            <motion.div 
              className="card overflow-hidden lg:col-span-3"
              whileHover={{ scale: 1.02 }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.3 }}
            >
              <div className="p-8 bg-gradient-to-r from-blue-700 to-blue-900 text-white">
                <h3 className="text-2xl font-bold mb-3">NEET Physics Complete Package</h3>
                <p className="text-white/90 mb-6 max-w-2xl">
                  Comprehensive preparation material for NEET Physics including notes, tests, previous year questions, and more.
                </p>
                <Link to="/store?tag=neet" className="btn bg-white text-blue-900 hover:bg-white/90">
                  View NEET Materials
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Student Success Stories</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Hear from students who have achieved great results with our study materials.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              className="card p-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center font-bold text-blue-700 mr-3">
                  AR
                </div>
                <div>
                  <h4 className="font-semibold">Aarav Rajput</h4>
                  <p className="text-sm text-gray-500">JEE Advanced 2024</p>
                </div>
              </div>
              <p className="text-gray-700">
                "The physics notes from BHAUTIK STUDY helped me understand complex concepts easily. I was able to score 95% in my boards and secure a good rank in JEE."
              </p>
            </motion.div>
            
            <motion.div 
              className="card p-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center font-bold text-green-700 mr-3">
                  SP
                </div>
                <div>
                  <h4 className="font-semibold">Sanya Patel</h4>
                  <p className="text-sm text-gray-500">NEET 2024</p>
                </div>
              </div>
              <p className="text-gray-700">
                "The practice tests were incredibly helpful for my NEET preparation. The explanations for each problem made it easy to understand my mistakes and improve."
              </p>
            </motion.div>
            
            <motion.div 
              className="card p-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.2 }}
            >
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center font-bold text-purple-700 mr-3">
                  VK
                </div>
                <div>
                  <h4 className="font-semibold">Vikram Kumar</h4>
                  <p className="text-sm text-gray-500">Class 12 CBSE</p>
                </div>
              </div>
              <p className="text-gray-700">
                "I was struggling with physics until I found BHAUTIK STUDY. The detailed notes and assignments helped me improve my understanding and I scored 92% in my board exams."
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-yellow-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Excel in Physics?</h2>
            <p className="text-gray-600 mb-8">
              Join thousands of students who have transformed their understanding of physics with our resources. Sign up today and get 100 free credits!
            </p>
            <Link to="/register" className="btn btn-primary text-lg px-8 py-3">
              Start Learning Now
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;