import React, { useState, useEffect } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { File, BookOpen, PenTool, Star, Filter, X } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '../context/AuthContext';
import { products, Product, Category } from '../data/products';

const StorePage: React.FC = () => {
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const initialCategory = queryParams.get('category') as Category | null;
  const initialClass = queryParams.get('class');
  const initialTag = queryParams.get('tag');
  const searchQuery = queryParams.get('q');

  const [selectedCategory, setSelectedCategory] = useState<Category | null>(initialCategory);
  const [selectedClass, setSelectedClass] = useState<string | null>(initialClass);
  const [selectedTag, setSelectedTag] = useState<string | null>(initialTag);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>(products);
  const [isFilterMenuOpen, setIsFilterMenuOpen] = useState(false);
  
  const { user } = useAuth();

  // Filter products based on selected filters and search query
  useEffect(() => {
    let result = [...products];
    
    if (selectedCategory) {
      result = result.filter(product => product.category === selectedCategory);
    }
    
    if (selectedClass) {
      result = result.filter(product => product.class === selectedClass);
    }
    
    if (selectedTag) {
      result = result.filter(product => product.tags.includes(selectedTag));
    }
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(product => 
        product.title.toLowerCase().includes(query) || 
        product.description.toLowerCase().includes(query) ||
        product.tags.some(tag => tag.toLowerCase().includes(query))
      );
    }
    
    setFilteredProducts(result);
  }, [selectedCategory, selectedClass, selectedTag, searchQuery]);

  const clearFilters = () => {
    setSelectedCategory(null);
    setSelectedClass(null);
    setSelectedTag(null);
  };

  const getCategoryIcon = (category: Category) => {
    switch (category) {
      case 'notes':
        return <BookOpen size={16} />;
      case 'assignments':
        return <PenTool size={16} />;
      case 'tests':
        return <File size={16} />;
      default:
        return <File size={16} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Study Materials</h1>
          {searchQuery && (
            <p className="text-gray-600">
              Search results for: <span className="font-medium">"{searchQuery}"</span>
            </p>
          )}
        </div>

        <div className="flex flex-col lg:flex-row gap-8">
          {/* Filters - Desktop */}
          <div className="hidden lg:block w-64 bg-white rounded-lg shadow-sm p-6 h-fit">
            <div className="mb-6">
              <h3 className="font-medium text-lg mb-3">Categories</h3>
              <div className="space-y-2">
                {(['notes', 'assignments', 'tests'] as Category[]).map(category => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(selectedCategory === category ? null : category)}
                    className={`w-full text-left px-3 py-2 rounded-md flex items-center ${
                      selectedCategory === category 
                        ? 'bg-blue-100 text-blue-700' 
                        : 'hover:bg-gray-100'
                    }`}
                  >
                    <span className="mr-2">{getCategoryIcon(category)}</span>
                    <span className="capitalize">{category}</span>
                  </button>
                ))}
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="font-medium text-lg mb-3">Class</h3>
              <div className="space-y-2">
                {['11', '12'].map(classNum => (
                  <button
                    key={classNum}
                    onClick={() => setSelectedClass(selectedClass === classNum ? null : classNum)}
                    className={`w-full text-left px-3 py-2 rounded-md ${
                      selectedClass === classNum 
                        ? 'bg-blue-100 text-blue-700' 
                        : 'hover:bg-gray-100'
                    }`}
                  >
                    Class {classNum}
                  </button>
                ))}
              </div>
            </div>
            
            <div className="mb-6">
              <h3 className="font-medium text-lg mb-3">Exams</h3>
              <div className="space-y-2">
                {['jee', 'neet'].map(tag => (
                  <button
                    key={tag}
                    onClick={() => setSelectedTag(selectedTag === tag ? null : tag)}
                    className={`w-full text-left px-3 py-2 rounded-md ${
                      selectedTag === tag 
                        ? 'bg-blue-100 text-blue-700' 
                        : 'hover:bg-gray-100'
                    }`}
                  >
                    {tag.toUpperCase()}
                  </button>
                ))}
              </div>
            </div>
            
            {(selectedCategory || selectedClass || selectedTag) && (
              <button
                onClick={clearFilters}
                className="flex items-center text-red-600 hover:text-red-700"
              >
                <X size={16} className="mr-1" /> Clear filters
              </button>
            )}
          </div>

          {/* Mobile Filter Button */}
          <div className="lg:hidden flex justify-between items-center mb-4 w-full">
            <button
              onClick={() => setIsFilterMenuOpen(!isFilterMenuOpen)}
              className="flex items-center bg-white px-4 py-2 rounded-md shadow-sm"
            >
              <Filter size={18} className="mr-2" /> 
              {isFilterMenuOpen ? 'Hide Filters' : 'Show Filters'}
            </button>
            
            {(selectedCategory || selectedClass || selectedTag) && (
              <button
                onClick={clearFilters}
                className="flex items-center text-red-600 bg-white px-4 py-2 rounded-md shadow-sm"
              >
                <X size={16} className="mr-1" /> Clear
              </button>
            )}
          </div>

          {/* Mobile Filter Menu */}
          {isFilterMenuOpen && (
            <div className="lg:hidden bg-white rounded-lg shadow-sm p-6 mb-4 w-full">
              <div className="mb-6">
                <h3 className="font-medium text-lg mb-3">Categories</h3>
                <div className="flex flex-wrap gap-2">
                  {(['notes', 'assignments', 'tests'] as Category[]).map(category => (
                    <button
                      key={category}
                      onClick={() => setSelectedCategory(selectedCategory === category ? null : category)}
                      className={`px-3 py-2 rounded-md flex items-center ${
                        selectedCategory === category 
                          ? 'bg-blue-100 text-blue-700' 
                          : 'bg-gray-100'
                      }`}
                    >
                      <span className="mr-2">{getCategoryIcon(category)}</span>
                      <span className="capitalize">{category}</span>
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="font-medium text-lg mb-3">Class</h3>
                <div className="flex flex-wrap gap-2">
                  {['11', '12'].map(classNum => (
                    <button
                      key={classNum}
                      onClick={() => setSelectedClass(selectedClass === classNum ? null : classNum)}
                      className={`px-3 py-2 rounded-md ${
                        selectedClass === classNum 
                          ? 'bg-blue-100 text-blue-700' 
                          : 'bg-gray-100'
                      }`}
                    >
                      Class {classNum}
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="font-medium text-lg mb-3">Exams</h3>
                <div className="flex flex-wrap gap-2">
                  {['jee', 'neet'].map(tag => (
                    <button
                      key={tag}
                      onClick={() => setSelectedTag(selectedTag === tag ? null : tag)}
                      className={`px-3 py-2 rounded-md ${
                        selectedTag === tag 
                          ? 'bg-blue-100 text-blue-700' 
                          : 'bg-gray-100'
                      }`}
                    >
                      {tag.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Products Grid */}
          <div className="flex-1">
            {filteredProducts.length === 0 ? (
              <div className="bg-white rounded-lg shadow-sm p-8 text-center">
                <h3 className="text-xl font-semibold mb-2">No materials found</h3>
                <p className="text-gray-600 mb-4">
                  We couldn't find any materials matching your criteria.
                </p>
                <button
                  onClick={clearFilters}
                  className="btn btn-primary"
                >
                  Clear Filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredProducts.map((product) => (
                  <motion.div
                    key={product.id}
                    className="card overflow-hidden"
                    whileHover={{ y: -5 }}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.3 }}
                  >
                    <div className="h-40 bg-gradient-to-r from-blue-100 to-blue-50 flex items-center justify-center">
                      {getCategoryIcon(product.category)}
                    </div>
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className={`badge ${
                          product.category === 'notes' ? 'badge-primary' :
                          product.category === 'assignments' ? 'badge-secondary' :
                          'bg-green-100 text-green-700'
                        }`}>
                          {product.category}
                        </span>
                        <div className="flex items-center text-yellow-500">
                          <Star size={16} fill="currentColor" />
                          <span className="ml-1 text-sm text-gray-700">{product.rating}</span>
                        </div>
                      </div>
                      <h3 className="text-lg font-semibold mb-2 line-clamp-2">{product.title}</h3>
                      <p className="text-gray-600 text-sm mb-4 line-clamp-3">
                        {product.description}
                      </p>
                      
                      <div className="flex flex-wrap gap-1 mb-4">
                        {product.tags.map(tag => (
                          <span key={tag} className="text-xs px-2 py-1 bg-gray-100 rounded-full">
                            {tag}
                          </span>
                        ))}
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <span className="font-semibold">{product.credits} Credits</span>
                        <Link 
                          to={`/store/${product.id}`} 
                          className="btn btn-primary"
                        >
                          View Details
                        </Link>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StorePage;