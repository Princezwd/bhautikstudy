import React, { useState, useEffect } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { User, ShoppingBag, CreditCard, Download, Clock } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '../context/AuthContext';
import { products, Product } from '../data/products';

// Dashboard sub-pages
import ProfileSection from '../components/dashboard/ProfileSection';
import PurchasesSection from '../components/dashboard/PurchasesSection';
import CreditsSection from '../components/dashboard/CreditsSection';

const DashboardPage: React.FC = () => {
  const location = useLocation();
  const { user } = useAuth();
  const [purchasedItems, setPurchasedItems] = useState<Product[]>([]);
  
  useEffect(() => {
    // Simulate fetching user's purchased items
    // In a real app, this would come from an API
    const mockPurchasedItems = products.slice(0, 3);
    setPurchasedItems(mockPurchasedItems);
  }, []);

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  const navItems = [
    { 
      path: '/dashboard', 
      label: 'Profile', 
      icon: <User size={20} /> 
    },
    { 
      path: '/dashboard/purchases', 
      label: 'My Purchases', 
      icon: <ShoppingBag size={20} /> 
    },
    { 
      path: '/dashboard/credits', 
      label: 'Credits', 
      icon: <CreditCard size={20} /> 
    },
  ];

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Sidebar */}
        <div className="lg:col-span-3">
          <div className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-center space-x-4 mb-6">
              <div className="bg-gradient-to-r from-blue-500 to-blue-600 h-12 w-12 rounded-full flex items-center justify-center text-white font-bold">
                {user?.name.charAt(0).toUpperCase()}
              </div>
              <div>
                <h2 className="font-semibold">{user?.name}</h2>
                <p className="text-sm text-gray-500">{user?.email}</p>
              </div>
            </div>
            
            <div className="bg-blue-50 p-3 rounded-lg flex items-center justify-between mb-6">
              <span className="text-sm">Available Credits</span>
              <span className="font-semibold">{user?.credits}</span>
            </div>
            
            <nav className="space-y-1">
              {navItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center space-x-3 px-4 py-3 rounded-md transition-colors ${
                    isActive(item.path)
                      ? 'bg-blue-50 text-blue-700'
                      : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  {item.icon}
                  <span>{item.label}</span>
                </Link>
              ))}
            </nav>
          </div>
        </div>
        
        {/* Main Content */}
        <div className="lg:col-span-9">
          <Routes>
            <Route index element={<ProfileSection />} />
            <Route path="purchases" element={<PurchasesSection purchases={purchasedItems} />} />
            <Route path="credits" element={<CreditsSection />} />
          </Routes>
          
          {/* Recent Activity - shown on all dashboard pages */}
          <motion.div 
            className="bg-white rounded-lg shadow-sm p-6 mt-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.2 }}
          >
            <h3 className="text-lg font-semibold mb-4">Recent Activity</h3>
            
            <div className="space-y-4">
              <div className="border-b pb-4">
                <div className="flex items-start">
                  <div className="bg-green-100 p-2 rounded-full mr-3">
                    <Download size={18} className="text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-medium">Downloaded "JEE Advanced Physics Formula Sheet"</h4>
                    <div className="flex items-center text-gray-500 text-sm mt-1">
                      <Clock size={14} className="mr-1" />
                      <span>Today at 10:24 AM</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="border-b pb-4">
                <div className="flex items-start">
                  <div className="bg-blue-100 p-2 rounded-full mr-3">
                    <ShoppingBag size={18} className="text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-medium">Purchased "Complete NEET Physics Test Series"</h4>
                    <div className="flex items-center text-gray-500 text-sm mt-1">
                      <Clock size={14} className="mr-1" />
                      <span>Yesterday at 4:30 PM</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="flex items-start">
                  <div className="bg-purple-100 p-2 rounded-full mr-3">
                    <CreditCard size={18} className="text-purple-600" />
                  </div>
                  <div>
                    <h4 className="font-medium">Received 100 welcome credits</h4>
                    <div className="flex items-center text-gray-500 text-sm mt-1">
                      <Clock size={14} className="mr-1" />
                      <span>2 days ago</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;