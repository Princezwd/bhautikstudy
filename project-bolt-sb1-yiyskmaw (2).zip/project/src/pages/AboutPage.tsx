import React from 'react';
import { motion } from 'framer-motion';
import { Award, Book, Users, Target, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const AboutPage: React.FC = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-700 to-blue-900 text-white py-16">
        <div className="container mx-auto px-4">
          <motion.div 
            className="max-w-3xl mx-auto text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-6">About BHAUTIK STUDY</h1>
            <p className="text-xl opacity-90 mb-8">
              Empowering students with quality physics education for academic excellence.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Our Story Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <p className="text-gray-700 mb-4">
                BHAUTIK STUDY was founded with a vision to make quality physics education accessible to students preparing for competitive exams like JEE and NEET, as well as those in classes 11 and 12.
              </p>
              <p className="text-gray-700 mb-4">
                Our founder, a passionate physics educator with over 15 years of experience, recognized the challenges students face in grasping complex physics concepts and the lack of structured, comprehensive study materials.
              </p>
              <p className="text-gray-700">
                Since our inception, we have been dedicated to creating high-quality, conceptually sound learning resources that help students develop a strong foundation in physics and excel in their examinations.
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <img 
                src="https://images.pexels.com/photos/256467/pexels-photo-256467.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Students learning physics" 
                className="rounded-lg shadow-lg"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Mission & Values Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Mission & Values</h2>
            <p className="text-gray-600">
              At BHAUTIK STUDY, we're driven by a clear mission and guided by core values that define everything we do.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <motion.div 
              className="bg-white p-8 rounded-lg shadow-sm"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
            >
              <h3 className="text-xl font-semibold mb-4 flex items-center">
                <Target size={24} className="text-blue-600 mr-2" />
                Our Mission
              </h3>
              <p className="text-gray-700">
                Our mission is to empower students with high-quality physics learning resources that build conceptual clarity, problem-solving skills, and examination confidence. We strive to make physics accessible, engaging, and rewarding for all students, regardless of their background or prior knowledge.
              </p>
            </motion.div>
            
            <motion.div 
              className="bg-white p-8 rounded-lg shadow-sm"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <h3 className="text-xl font-semibold mb-4 flex items-center">
                <Award size={24} className="text-blue-600 mr-2" />
                Our Values
              </h3>
              <ul className="space-y-3 text-gray-700">
                <li className="flex items-start">
                  <span className="bg-blue-100 text-blue-700 rounded-full p-1 mr-2 flex-shrink-0 mt-0.5">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </span>
                  <span><strong>Excellence:</strong> We are committed to delivering the highest quality educational content.</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-blue-100 text-blue-700 rounded-full p-1 mr-2 flex-shrink-0 mt-0.5">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </span>
                  <span><strong>Accessibility:</strong> We believe quality education should be available to all students.</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-blue-100 text-blue-700 rounded-full p-1 mr-2 flex-shrink-0 mt-0.5">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </span>
                  <span><strong>Innovation:</strong> We constantly improve our teaching methods and materials.</span>
                </li>
                <li className="flex items-start">
                  <span className="bg-blue-100 text-blue-700 rounded-full p-1 mr-2 flex-shrink-0 mt-0.5">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </span>
                  <span><strong>Student-Centric:</strong> Our students' success is our highest priority.</span>
                </li>
              </ul>
            </motion.div>
          </div>
        </div>
      </section>

      {/* What Sets Us Apart Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">What Sets Us Apart</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              BHAUTIK STUDY offers a unique approach to learning physics that helps students truly excel.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <motion.div 
              className="bg-blue-50 p-6 rounded-lg"
              whileHover={{ y: -5 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <div className="bg-blue-100 h-14 w-14 rounded-full flex items-center justify-center mb-4 text-blue-700">
                <Book size={24} />
              </div>
              <h3 className="text-lg font-semibold mb-2">Comprehensive Content</h3>
              <p className="text-gray-700">
                Our meticulously crafted notes, assignments, and tests cover the entire syllabus, structured to build conceptual clarity.
              </p>
            </motion.div>
            
            <motion.div 
              className="bg-green-50 p-6 rounded-lg"
              whileHover={{ y: -5 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.2 }}
            >
              <div className="bg-green-100 h-14 w-14 rounded-full flex items-center justify-center mb-4 text-green-700">
                <Users size={24} />
              </div>
              <h3 className="text-lg font-semibold mb-2">Expert Educators</h3>
              <p className="text-gray-700">
                Our content is created by experienced educators with a proven track record of helping students excel in competitive exams.
              </p>
            </motion.div>
            
            <motion.div 
              className="bg-purple-50 p-6 rounded-lg"
              whileHover={{ y: -5 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.3 }}
            >
              <div className="bg-purple-100 h-14 w-14 rounded-full flex items-center justify-center mb-4 text-purple-700">
                <Target size={24} />
              </div>
              <h3 className="text-lg font-semibold mb-2">Exam-Focused</h3>
              <p className="text-gray-700">
                Our materials are specifically designed to help students succeed in CBSE boards, JEE, and NEET examinations.
              </p>
            </motion.div>
            
            <motion.div 
              className="bg-yellow-50 p-6 rounded-lg"
              whileHover={{ y: -5 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: 0.4 }}
            >
              <div className="bg-yellow-100 h-14 w-14 rounded-full flex items-center justify-center mb-4 text-yellow-700">
                <Award size={24} />
              </div>
              <h3 className="text-lg font-semibold mb-2">Flexible Credit System</h3>
              <p className="text-gray-700">
                Our innovative credit system allows students to purchase only what they need, making quality education affordable.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Meet Our Team</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our team of dedicated educators is passionate about helping students excel in physics.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              className="bg-white rounded-lg overflow-hidden shadow-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3 }}
            >
              <img 
                src="https://images.pexels.com/photos/5490276/pexels-photo-5490276.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Dr. Rahul Sharma" 
                className="w-full h-56 object-cover object-center"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-1">Dr. Rahul Sharma</h3>
                <p className="text-blue-600 mb-3">Founder & Lead Educator</p>
                <p className="text-gray-600">
                  PhD in Physics with 15+ years of teaching experience. Former lecturer at IIT and author of multiple textbooks.
                </p>
              </div>
            </motion.div>
            
            <motion.div 
              className="bg-white rounded-lg overflow-hidden shadow-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.1 }}
            >
              <img 
                src="https://images.pexels.com/photos/5212703/pexels-photo-5212703.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Prof. Anjali Patel" 
                className="w-full h-56 object-cover object-center"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-1">Prof. Anjali Patel</h3>
                <p className="text-blue-600 mb-3">Content Director</p>
                <p className="text-gray-600">
                  MSc in Physics with specialization in curriculum development. Expert in creating engaging and effective study materials.
                </p>
              </div>
            </motion.div>
            
            <motion.div 
              className="bg-white rounded-lg overflow-hidden shadow-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.3, delay: 0.2 }}
            >
              <img 
                src="https://images.pexels.com/photos/8197559/pexels-photo-8197559.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="Vikram Malhotra" 
                className="w-full h-56 object-cover object-center"
              />
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-1">Vikram Malhotra</h3>
                <p className="text-blue-600 mb-3">JEE & NEET Expert</p>
                <p className="text-gray-600">
                  Former JEE topper with 10+ years of experience coaching students for competitive exams. Known for problem-solving techniques.
                </p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-700 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">Ready to Excel in Physics?</h2>
            <p className="text-xl opacity-90 mb-8">
              Join thousands of students who have transformed their understanding of physics with our resources.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link to="/register" className="btn bg-white text-blue-700 hover:bg-gray-100">
                Register Now
              </Link>
              <Link to="/store" className="btn bg-blue-600 text-white hover:bg-blue-500 flex items-center justify-center">
                Browse Study Materials <ArrowRight size={16} className="ml-2" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;