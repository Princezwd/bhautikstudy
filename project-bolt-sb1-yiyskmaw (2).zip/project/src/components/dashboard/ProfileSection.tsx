import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { motion } from 'framer-motion';
import { Save, User } from 'lucide-react';

const ProfileSection: React.FC = () => {
  const { user } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [email, setEmail] = useState(user?.email || '');
  const [isSaving, setIsSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSaving(false);
      setSuccessMessage('Profile updated successfully!');
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccessMessage('');
      }, 3000);
    }, 1000);
  };

  return (
    <motion.div
      className="bg-white rounded-lg shadow-sm p-6"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex items-center mb-6">
        <User size={24} className="mr-2 text-gray-700" />
        <h2 className="text-xl font-semibold">My Profile</h2>
      </div>
      
      {successMessage && (
        <div className="bg-green-50 text-green-600 p-4 rounded-md mb-6">
          {successMessage}
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <label htmlFor="name" className="block text-gray-700 font-medium mb-2">
              Full Name
            </label>
            <input
              type="text"
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="input w-full"
              required
            />
          </div>
          
          <div>
            <label htmlFor="email" className="block text-gray-700 font-medium mb-2">
              Email Address
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="input w-full"
              required
            />
          </div>
          
          <div>
            <label htmlFor="phone" className="block text-gray-700 font-medium mb-2">
              Phone Number
            </label>
            <input
              type="tel"
              id="phone"
              className="input w-full"
              placeholder="Enter your phone number"
            />
          </div>
          
          <div>
            <label htmlFor="class" className="block text-gray-700 font-medium mb-2">
              Class/Grade
            </label>
            <select id="class" className="input w-full">
              <option value="">Select your class</option>
              <option value="11">Class 11</option>
              <option value="12">Class 12</option>
              <option value="jee">JEE Preparation</option>
              <option value="neet">NEET Preparation</option>
            </select>
          </div>
        </div>
        
        <div className="mb-6">
          <h3 className="font-medium text-gray-700 mb-2">Notification Preferences</h3>
          <div className="space-y-3">
            <div className="flex items-center">
              <input
                type="checkbox"
                id="emailNotif"
                className="h-4 w-4 text-blue-600 rounded"
                defaultChecked
              />
              <label htmlFor="emailNotif" className="ml-2 text-gray-700">
                Email notifications for new study materials
              </label>
            </div>
            <div className="flex items-center">
              <input
                type="checkbox"
                id="promoNotif"
                className="h-4 w-4 text-blue-600 rounded"
                defaultChecked
              />
              <label htmlFor="promoNotif" className="ml-2 text-gray-700">
                Special offers and promotions
              </label>
            </div>
          </div>
        </div>
        
        <div>
          <button
            type="submit"
            className="btn btn-primary flex items-center"
            disabled={isSaving}
          >
            {isSaving ? (
              <>
                <span className="animate-spin h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full"></span>
                Saving...
              </>
            ) : (
              <>
                <Save size={18} className="mr-2" />
                Save Changes
              </>
            )}
          </button>
        </div>
      </form>
    </motion.div>
  );
};

export default ProfileSection;