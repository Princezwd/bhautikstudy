import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useAuth } from '../../context/AuthContext';
import { CreditCard, Plus, AlertCircle, Clock, Gift } from 'lucide-react';

const CreditsSection: React.FC = () => {
  const { user, updateCredits } = useAuth();
  const [selectedPlan, setSelectedPlan] = useState<number | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  
  const creditPlans = [
    { id: 1, credits: 100, price: 199, popular: false },
    { id: 2, credits: 500, price: 699, popular: true },
    { id: 3, credits: 1000, price: 1299, popular: false },
  ];
  
  const handlePurchase = () => {
    if (!selectedPlan) return;
    
    setIsProcessing(true);
    
    // Simulate API call for purchasing credits
    setTimeout(() => {
      const plan = creditPlans.find(p => p.id === selectedPlan);
      if (plan && user) {
        const newCredits = user.credits + plan.credits;
        updateCredits(newCredits);
        setSuccessMessage(`Successfully added ${plan.credits} credits to your account!`);
        setSelectedPlan(null);
      }
      
      setIsProcessing(false);
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccessMessage('');
      }, 3000);
    }, 1500);
  };

  return (
    <motion.div
      className="bg-white rounded-lg shadow-sm p-6"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex items-center mb-6">
        <CreditCard size={24} className="mr-2 text-gray-700" />
        <h2 className="text-xl font-semibold">Credit Management</h2>
      </div>
      
      {successMessage && (
        <div className="bg-green-50 text-green-600 p-4 rounded-md mb-6">
          {successMessage}
        </div>
      )}
      
      <div className="bg-blue-50 p-4 rounded-lg mb-8">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="font-medium text-blue-800">Current Balance</h3>
            <p className="text-gray-600 text-sm mt-1">
              Use credits to purchase study materials
            </p>
          </div>
          <div className="text-3xl font-bold text-blue-700">
            {user?.credits || 0}
          </div>
        </div>
      </div>
      
      <div className="mb-8">
        <h3 className="font-medium text-lg mb-4">Purchase Credits</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {creditPlans.map((plan) => (
            <div
              key={plan.id}
              className={`border rounded-lg p-4 cursor-pointer transition-all relative ${
                selectedPlan === plan.id
                  ? 'border-blue-500 bg-blue-50'
                  : 'hover:border-gray-300'
              }`}
              onClick={() => setSelectedPlan(plan.id)}
            >
              {plan.popular && (
                <div className="absolute top-0 right-0 transform translate-x-1/4 -translate-y-1/3">
                  <span className="bg-yellow-400 text-xs font-bold px-2 py-1 rounded-full text-blue-900">
                    POPULAR
                  </span>
                </div>
              )}
              <div className="text-center">
                <h4 className="font-medium text-lg">{plan.credits} Credits</h4>
                <div className="text-2xl font-bold my-2">₹{plan.price}</div>
                <p className="text-gray-500 text-sm">
                  {plan.id === 2 ? 'Best value' : 'One-time purchase'}
                </p>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-6">
          <button
            onClick={handlePurchase}
            disabled={!selectedPlan || isProcessing}
            className={`btn ${
              selectedPlan ? 'btn-primary' : 'bg-gray-300 cursor-not-allowed'
            } flex items-center`}
          >
            {isProcessing ? (
              <>
                <span className="animate-spin h-4 w-4 mr-2 border-2 border-white border-t-transparent rounded-full"></span>
                Processing...
              </>
            ) : (
              <>
                <Plus size={18} className="mr-2" />
                Purchase Credits
              </>
            )}
          </button>
          <p className="text-xs text-gray-500 mt-2 flex items-center">
            <AlertCircle size={12} className="mr-1" />
            This is a demo. No actual payment will be processed.
          </p>
        </div>
      </div>
      
      <div>
        <h3 className="font-medium text-lg mb-4">Credit History</h3>
        
        <div className="space-y-4">
          <div className="border-b pb-4">
            <div className="flex items-start">
              <div className="bg-green-100 p-2 rounded-full mr-3">
                <Gift size={18} className="text-green-600" />
              </div>
              <div>
                <div className="flex justify-between">
                  <h4 className="font-medium">Welcome Bonus</h4>
                  <span className="text-green-600 font-medium">+100 Credits</span>
                </div>
                <div className="flex items-center text-gray-500 text-sm mt-1">
                  <Clock size={14} className="mr-1" />
                  <span>Account Registration</span>
                </div>
              </div>
            </div>
          </div>
          
          {user && user.credits > 100 && (
            <div className="border-b pb-4">
              <div className="flex items-start">
                <div className="bg-blue-100 p-2 rounded-full mr-3">
                  <CreditCard size={18} className="text-blue-600" />
                </div>
                <div>
                  <div className="flex justify-between">
                    <h4 className="font-medium">Credit Purchase</h4>
                    <span className="text-green-600 font-medium">+500 Credits</span>
                  </div>
                  <div className="flex items-center text-gray-500 text-sm mt-1">
                    <Clock size={14} className="mr-1" />
                    <span>2 days ago</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default CreditsSection;