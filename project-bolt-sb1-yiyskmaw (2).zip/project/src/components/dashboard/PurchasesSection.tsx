import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Download, File, BookOpen, PenTool, ShoppingBag } from 'lucide-react';
import { Product } from '../../data/products';

interface PurchasesSectionProps {
  purchases: Product[];
}

const PurchasesSection: React.FC<PurchasesSectionProps> = ({ purchases }) => {
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'notes':
        return <BookOpen size={18} />;
      case 'assignments':
        return <PenTool size={18} />;
      case 'tests':
        return <File size={18} />;
      default:
        return <File size={18} />;
    }
  };

  return (
    <motion.div
      className="bg-white rounded-lg shadow-sm p-6"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="flex items-center mb-6">
        <ShoppingBag size={24} className="mr-2 text-gray-700" />
        <h2 className="text-xl font-semibold">My Purchases</h2>
      </div>
      
      {purchases.length === 0 ? (
        <div className="text-center py-12">
          <div className="bg-gray-100 h-20 w-20 rounded-full flex items-center justify-center mx-auto mb-4">
            <ShoppingBag size={32} className="text-gray-400" />
          </div>
          <h3 className="text-lg font-medium mb-2">No purchases yet</h3>
          <p className="text-gray-500 mb-6 max-w-md mx-auto">
            You haven't purchased any study materials yet. Browse our store to find what you need.
          </p>
          <Link to="/store" className="btn btn-primary">
            Browse Store
          </Link>
        </div>
      ) : (
        <div className="space-y-6">
          {purchases.map((purchase) => (
            <div 
              key={purchase.id} 
              className="border rounded-lg p-4 hover:shadow-md transition-shadow"
            >
              <div className="flex flex-col md:flex-row md:items-center justify-between">
                <div className="flex items-start space-x-4 mb-4 md:mb-0">
                  <div className={`p-3 rounded-md ${
                    purchase.category === 'notes' ? 'bg-blue-100 text-blue-600' :
                    purchase.category === 'assignments' ? 'bg-green-100 text-green-600' :
                    'bg-purple-100 text-purple-600'
                  }`}>
                    {getCategoryIcon(purchase.category)}
                  </div>
                  <div>
                    <h3 className="font-medium">{purchase.title}</h3>
                    <div className="flex items-center text-sm text-gray-500 mt-1">
                      <span className="capitalize">{purchase.category}</span>
                      <span className="mx-2">•</span>
                      <span>Purchased on 12 May 2025</span>
                    </div>
                  </div>
                </div>
                <button className="btn btn-primary flex items-center justify-center">
                  <Download size={16} className="mr-2" />
                  Download
                </button>
              </div>
            </div>
          ))}
          
          <div className="text-center mt-6">
            <Link to="/store" className="text-blue-600 hover:text-blue-800 font-medium inline-flex items-center">
              <ShoppingBag size={16} className="mr-1" />
              Browse more study materials
            </Link>
          </div>
        </div>
      )}
    </motion.div>
  );
};

export default PurchasesSection;